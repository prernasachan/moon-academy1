# Moon Academy — Canvas App Source Export

This folder contains the readable Power Apps source YAML extracted from the supplied `.msapp` package.

## Contents
- `Screens/` — 16 individual screen definitions (`.pa.yaml`).
- `Components/` — 3 reusable component definitions (`.pa.yaml`).
- `App/` — application-level definition and initialization formulas.

## Important
- These are source exports for inspection and version-control reference; they are not standalone runnable applications.
- Import/reconstruction should be performed through Power Apps Studio / supported Power Platform source workflows.
- The original organization-specific project label and PMO mailbox references found in the source were replaced with Moon Academy and `academy-operations@moon.example`.
- Data-source names, connector names, environment references and schema dependencies may still need configuration in a separate demonstration environment.
- Review all formulas and connections before deploying.
